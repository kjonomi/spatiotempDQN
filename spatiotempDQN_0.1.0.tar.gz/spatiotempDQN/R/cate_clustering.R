#' Compute CATE contrasts and clustering
#' @param X features
#' @param Y_obs observed rewards
#' @return Cluster assignments
#' @export
cate_clustering <- function(X, Y_obs, n_clusters = 3) {
  km <- kmeans(Y_obs, centers = n_clusters)
  km$cluster
}