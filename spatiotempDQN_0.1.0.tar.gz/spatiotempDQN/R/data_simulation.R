#' Generate synthetic spatio-temporal features
#' @param n_obs Number of observations
#' @param T_steps Number of time steps
#' @param p Number of features
#' @return Array of dimension (n_obs, T_steps, p)
#' @export
simulate_temporal_features <- function(n_obs = 100, T_steps = 10, p = 5) {
  array(rnorm(n_obs * T_steps * p), dim = c(n_obs, T_steps, p))
}