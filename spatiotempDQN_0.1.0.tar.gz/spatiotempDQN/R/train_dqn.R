#' Train DQN model
#' @param model keras model
#' @param X array of features
#' @param W vector of actions
#' @param Y_obs matrix of rewards
#' @param epochs Number of training epochs
#' @return Trained keras model
#' @export
train_dqn_model <- function(model, X, W, Y_obs, epochs = 5) {
  model %>% compile(
    optimizer = "adam",
    loss = "mse"
  )
  model %>% fit(X, Y_obs, epochs = epochs, verbose = 0)
  model
}