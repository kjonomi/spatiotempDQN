#' Build CNN-LSTM DQN model
#' @param input_shape Input shape array: (T_steps, n_features)
#' @param n_actions Number of actions
#' @return keras model
#' @export
build_cnn_lstm_dqn <- function(input_shape, n_actions) {
  library(keras)
  model <- keras_model_sequential() %>%
    layer_conv_1d(filters = 16, kernel_size = 3, activation = "relu",
                  input_shape = input_shape) %>%
    layer_lstm(32, return_sequences = FALSE) %>%
    layer_dense(32, activation = "relu") %>%
    layer_dense(n_actions, activation = "linear")
  model
}