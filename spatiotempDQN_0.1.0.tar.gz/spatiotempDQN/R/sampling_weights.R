#' Compute sampling weights for weighted training
#' @param rewards matrix of observed rewards
#' @return numeric vector of sampling weights
#' @export
compute_sampling_weights <- function(rewards) {
  rowMeans(abs(rewards), na.rm = TRUE)
}