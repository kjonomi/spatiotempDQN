#' Prepare NYC Flights dataset for DQN
#' @param T_steps Number of time steps
#' @return List with X_train, Y_obs_train
#' @export
prepare_nycflights <- function(T_steps = 10) {
  library(nycflights13)
  flights_sub <- nycflights13::flights[1:(T_steps*50), ]
  X_train <- as.matrix(flights_sub[, c("dep_delay","arr_delay","air_time")])
  Y_obs_train <- matrix(runif(nrow(X_train)*3), ncol=3)
  list(X_train = X_train, Y_obs_train = Y_obs_train)
}