context('core functionality')

test_that('simulate_spatiotemp returns expected shapes', {
  dat <- simulate_spatiotemp(n = 20, T_steps = 3, p = 2, seed = 123)
  expect_is(dat$X_train, 'array')
  expect_true(ncol(dat$Y_obs_train) == 2)
})
