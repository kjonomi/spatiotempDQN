library(testthat)
library(spatiotempDQN)
test_check("spatiotempDQN")
