# Example simulation run
data <- simulate_spatiotemp(n = 100)
print(dim(data$X_train))
